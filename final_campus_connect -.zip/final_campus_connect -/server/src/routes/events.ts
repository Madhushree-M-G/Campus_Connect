// server/src/routes/events.ts
import express from 'express';
import Event from '../models/Event';
import { authenticateToken } from '../middleware/auth';

const router = express.Router();

// Get all events with filters
router.get('/', async (req, res) => {
  try {
    const {
      category,
      search,
      skills,
      location,
      isOnline,
      sortBy = 'createdAt',
      sortOrder = 'desc',
      page = 1,
      limit = 20
    } = req.query;

    const filter: any = { isActive: true };

    if (category && category !== 'all') {
      filter.category = category;
    }

    if (search) {
      filter.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { company: { $regex: search, $options: 'i' } }
      ];
    }

    if (skills) {
      const skillsArray = (skills as string).split(',');
      filter.skills = { $in: skillsArray };
    }

    if (location && location !== 'all') {
      filter.location = { $regex: location, $options: 'i' };
    }

    if (isOnline === 'true') {
      filter.isOnline = true;
    }

    const sortOptions: any = {};
    sortOptions[sortBy as string] = sortOrder === 'desc' ? -1 : 1;

    const events = await Event.find(filter)
      .sort(sortOptions)
      .limit(Number(limit))
      .skip((Number(page) - 1) * Number(limit));

    const total = await Event.countDocuments(filter);

    res.json({
      events,
      pagination: {
        current: Number(page),
        pages: Math.ceil(total / Number(limit)),
        total
      }
    });
  } catch (error) {
    console.error('Get events error:', error);
    res.status(500).json({ error: 'Failed to fetch events' });
  }
});

// Get single event
router.get('/:id', async (req, res) => {
  try {
    const event = await Event.findById(req.params.id);
    if (!event) {
      return res.status(404).json({ error: 'Event not found' });
    }
    res.json(event);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch event' });
  }
});

// Bookmark event
router.post('/:id/bookmark', authenticateToken, async (req: any, res) => {
  try {
    const user = req.user;
    const eventId = req.params.id;

    if (user.bookmarks.includes(eventId)) {
      user.bookmarks = user.bookmarks.filter((id: any) => id.toString() !== eventId);
    } else {
      user.bookmarks.push(eventId);
    }

    await user.save();
    res.json({ message: 'Bookmark updated', bookmarks: user.bookmarks });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update bookmark' });
  }
});

// Get user bookmarks
router.get('/user/bookmarks', authenticateToken, async (req: any, res) => {
  try {
    const user = await req.user.populate('bookmarks');
    res.json(user.bookmarks);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch bookmarks' });
  }
});

export default router;