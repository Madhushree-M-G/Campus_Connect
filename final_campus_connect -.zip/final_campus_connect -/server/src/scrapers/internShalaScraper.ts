// server/src/scrapers/internShalaScraper.ts
import axios from 'axios';
import * as cheerio from 'cheerio';

export const internShalaScraper = async () => {
  const events: any[] = [];  // ✅ Explicitly typed as any[]
  
  try {
    const url = 'https://internshala.com/internships';
    
    const response = await axios.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      },
      timeout: 10000
    });

    const $ = cheerio.load(response.data);
    
    $('.internship_meta, .individual_internship').each((i, element) => {
      try {
        const $el = $(element);
        const title = $el.find('.job-internship-name, .profile').text().trim();
        const company = $el.find('.company-name, .company').text().trim();
        const location = $el.find('.locations, .location').text().trim();
        const duration = $el.find('.duration').text().trim();
        const stipend = $el.find('.stipend').text().trim();
        const deadline = parseDate($el.find('.application-deadline, .deadline').text().trim()); // ✅ parseDate already defined
        const internshipUrl = $el.find('a').attr('href');
        
        if (title && deadline && internshipUrl) {
          events.push({
            title: `${title} - ${company}`,
            description: `Duration: ${duration}, Stipend: ${stipend}`,
            category: 'internship',
            source: 'Internshala',
            url: internshipUrl.startsWith('http') ? internshipUrl : `https://internshala.com${internshipUrl}`,
            startDate: new Date(),
            deadline: deadline,
            location: location || 'Not specified',
            isOnline: location.toLowerCase().includes('remote') || location.toLowerCase().includes('online'),
            skills: extractSkills(title),  // ✅ extractSkills already defined
            eligibility: ['Students'],
            company: company,
            difficulty: 'Beginner'
          });
        }
      } catch (error) {
        console.error('Error parsing Internshala event:', error);
      }
    });
  } catch (error) {
    console.error('Internshala scraper error:', error);
  }

  return events;
};

// ✅ Utility functions (no change, just keeping them for reference)
const parseDate = (dateStr: string): Date => {
  try {
    const cleanStr = dateStr.replace(/[^\w\s:/-]/g, '').trim();
    if (!cleanStr) return new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
    const parsed = new Date(cleanStr);
    if (!isNaN(parsed.getTime())) {
      return parsed;
    }
    return new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
  } catch {
    return new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
  }
};

const extractSkills = (text: string): string[] => {
  const skillKeywords = [
    'JavaScript', 'Python', 'Java', 'C++', 'React', 'Node.js', 'MongoDB',
    'Machine Learning', 'AI', 'Data Science', 'Web Development', 'Mobile',
    'Android', 'iOS', 'Flutter', 'React Native', 'DevOps', 'Cloud',
    'AWS', 'Azure', 'Docker', 'Kubernetes', 'Blockchain', 'IoT',
    'Cybersecurity', 'UI/UX', 'Design', 'Marketing', 'Sales', 'Finance'
  ];
  const foundSkills = skillKeywords.filter(skill =>
    text.toLowerCase().includes(skill.toLowerCase())
  );
  return foundSkills.length > 0 ? foundSkills : ['Programming'];
};
