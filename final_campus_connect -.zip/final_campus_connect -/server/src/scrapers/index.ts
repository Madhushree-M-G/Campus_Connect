// server/src/scrapers/index.ts

import { internShalaScraper } from './internShalaScraper';
import { workIndiaScraper } from './workIndiaScraper';


import Event from '../models/Event';
import User from '../models/User';
import Notification from '../models/Notification';

export const runAllScrapers = async () => {
  console.log('Starting scraping process...');
  
  try {
    const scrapers = [
  
      { name: 'Internshala', scraper: internShalaScraper },
     { name: 'WorkIndia', scraper: workIndiaScraper },

    
      
    ];

    let totalNewEvents = 0;

    for (const { name, scraper } of scrapers) {
      try {
        console.log(`Running ${name} scraper...`);
        const events = await scraper();
        
        for (const eventData of events) {
          try {
            const existingEvent = await Event.findOne({
              source: eventData.source,
              url: eventData.url
            });

            if (!existingEvent) {
              const event = new Event(eventData);
              await event.save();
              totalNewEvents++;

              // Notify relevant users
              await notifyUsers(event);
              console.log(`New event saved: ${event.title}`);
            }
          } catch (error) {
            console.error(`Error saving event: ${eventData.title}`, error);
          }
        }
        
        console.log(`${name} scraper completed: ${events.length} events processed`);
      } catch (error) {
        console.error(`${name} scraper failed:`, error);
      }
    }

    console.log(`Scraping completed: ${totalNewEvents} new events added`);
    return totalNewEvents;
  } catch (error) {
    console.error('Scraping process failed:', error);
    throw error;
  }
};

const notifyUsers = async (event: any) => {
  try {
    const users = await User.find({
      notifications: true,
      $or: [
        { interests: { $in: [event.category] } },
        { skills: { $in: event.skills } }
      ]
    });

    const notifications = users.map(user => ({
      userId: user._id,
      eventId: event._id,
      type: 'new_event' as const,
      message: `New ${event.category}: ${event.title}`
    }));

    if (notifications.length > 0) {
      await Notification.insertMany(notifications);
      
      // Send real-time notifications
      if (global.io) {
        users.forEach(user => {
          global.io.to(`user-${user._id}`).emit('new-notification', {
            event: event,
            message: `New ${event.category}: ${event.title}`
          });
        });
      }
    }
  } catch (error) {
    console.error('Error notifying users:', error);
  }
};