// server/src/scrapers/workIndiaScraper.ts
import axios from 'axios';
import * as cheerio from 'cheerio';

export const workIndiaScraper = async () => {
  const url = 'https://www.workindia.in/jobs';
  const events: any[] = [];

  try {
    const { data } = await axios.get(url);
    const $ = cheerio.load(data);

    $('.job-container').each((_, el) => {
      const title = $(el).find('.job-title').text().trim();
      const company = $(el).find('.company-name').text().trim();
      const location = $(el).find('.location').text().trim();
      const salary = $(el).find('.salary').text().trim();
      const posted = $(el).find('.posted-date').text().trim();
      const jobUrl = 'https://www.workindia.in' + ($(el).find('a').attr('href') || '');

      if (title && jobUrl) {
        events.push({
          title,
          company,
          location,
          salary,
          posted,
          url: jobUrl,
          source: 'WorkIndia',
          category: 'Job',
          skills: [],
        });
      }
    });

    console.log(`WorkIndia scraper collected: ${events.length} jobs`);
    return events;
  } catch (error) {
    console.error('Error scraping WorkIndia:', error);
    return [];
  }
};
