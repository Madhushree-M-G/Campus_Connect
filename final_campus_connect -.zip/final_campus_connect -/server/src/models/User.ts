import mongoose, { Document, Schema } from 'mongoose';

export interface IUser extends Document {
  googleId: string;
  email: string;
  name: string;
  picture: string;
  skills: string[];
  interests: string[];
  bookmarks: mongoose.Types.ObjectId[];
  notifications: boolean;
  createdAt: Date;
  lastLogin: Date;
}

const userSchema = new Schema<IUser>({
  googleId: { type: String, required: true, unique: true },
  email: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  picture: { type: String, required: true },
  skills: [{ type: String }],
  interests: [{ type: String }],
  bookmarks: [{ type: Schema.Types.ObjectId, ref: 'Event' }],
  notifications: { type: Boolean, default: true },
  createdAt: { type: Date, default: Date.now },
  lastLogin: { type: Date, default: Date.now }
});

export default mongoose.model<IUser>('User', userSchema);
