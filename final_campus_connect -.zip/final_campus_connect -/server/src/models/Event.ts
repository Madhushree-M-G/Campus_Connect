import mongoose, { Document, Schema } from 'mongoose';

export interface IEvent extends Document {
  title: string;
  description: string;
  category: 'hackathon' | 'internship' | 'placement' | 'competition' | 'workshop';
  source: string;
  url: string;
  imageUrl?: string;
  startDate: Date;
  endDate?: Date;
  deadline: Date;
  location: string;
  isOnline: boolean;
  skills: string[];
  eligibility: string[];
  prize?: string;
  company?: string;
  registrationCount?: number;
  difficulty?: 'Beginner' | 'Intermediate' | 'Advanced';
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const eventSchema = new Schema<IEvent>({
  title: { type: String, required: true },
  description: { type: String, required: true },
  category: { 
    type: String, 
    enum: ['hackathon', 'internship', 'placement', 'competition', 'workshop'],
    required: true 
  },
  source: { type: String, required: true },
  url: { type: String, required: true },
  imageUrl: { type: String },
  startDate: { type: Date, required: true },
  endDate: { type: Date },
  deadline: { type: Date, required: true },
  location: { type: String, required: true },
  isOnline: { type: Boolean, default: false },
  skills: [{ type: String }],
  eligibility: [{ type: String }],
  prize: { type: String },
  company: { type: String },
  registrationCount: { type: Number, default: 0 },
  difficulty: { 
    type: String, 
    enum: ['Beginner', 'Intermediate', 'Advanced'],
    default: 'Intermediate'
  },
  isActive: { type: Boolean, default: true },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// Create indexes for better performance
eventSchema.index({ category: 1, isActive: 1 });
eventSchema.index({ deadline: 1 });
eventSchema.index({ skills: 1 });
eventSchema.index({ source: 1, url: 1 }, { unique: true });

export default mongoose.model<IEvent>('Event', eventSchema);
