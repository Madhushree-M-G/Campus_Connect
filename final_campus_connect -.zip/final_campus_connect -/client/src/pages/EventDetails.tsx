// client/src/pages/EventDetails.tsx
import React, { useEffect, useState ,useCallback } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../contexts/AuthContext';
import LoadingSpinner from '../components/LoadingSpinner';
import toast from 'react-hot-toast';
import {
  CalendarDaysIcon,
  MapPinIcon,
  ClockIcon,
  BookmarkIcon,
  ArrowTopRightOnSquareIcon,
  TrophyIcon,
  BuildingOfficeIcon,
  ChartBarIcon
} from '@heroicons/react/24/outline';
import { BookmarkIcon as BookmarkSolidIcon } from '@heroicons/react/24/solid';

const EventDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const [event, setEvent] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [bookmarked, setBookmarked] = useState(false);


  const fetchEvent = useCallback(async () => {
  try {
    const response = await axios.get(
      `${process.env.REACT_APP_API_URL}/events/${id}`
    );
    setEvent(response.data);
  } catch (error) {
    console.error("Error fetching event:", error);
  } finally {
    setLoading(false);
  }
}, [id]);

useEffect(() => {
  if (id) {
    fetchEvent();
  }
}, [id, fetchEvent]); // ✅ safe now

  useEffect(() => {
    if (user && event) {
      setBookmarked(user.bookmarks.includes(event._id));
    }
  }, [user, event]);

  

  const handleBookmark = async () => {
    if (!user) {
      toast.error('Please sign in to bookmark events');
      return;
    }

    try {
      await axios.post(`${process.env.REACT_APP_API_URL}/events/${id}/bookmark`);
      setBookmarked(!bookmarked);
      toast.success(bookmarked ? 'Bookmark removed' : 'Event bookmarked');
    } catch (error) {
      console.error('Error bookmarking event:', error);
      toast.error('Failed to bookmark event');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-96">
        <LoadingSpinner />
      </div>
    );
  }

  if (!event) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold text-gray-700 mb-4">Event not found</h2>
        <Link to="/events" className="text-blue-600 hover:text-blue-700">
          Back to Events
        </Link>
      </div>
    );
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getCategoryColor = (category: string) => {
    const colors: { [key: string]: string } = {
      hackathon: 'from-purple-500 to-pink-500',
      internship: 'from-blue-500 to-cyan-500',
      competition: 'from-green-500 to-emerald-500',
      workshop: 'from-orange-500 to-red-500'
    };
    return colors[category] || 'from-gray-500 to-gray-600';
  };

  const isDeadlineNear = () => {
    const deadline = new Date(event.deadline);
    const now = new Date();
    const daysLeft = Math.ceil((deadline.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return daysLeft <= 7;
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Header */}
      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        {event.imageUrl && (
          <div className="h-64 bg-gray-200 overflow-hidden">
            <img
              src={event.imageUrl}
              alt={event.title}
              className="w-full h-full object-cover"
            />
          </div>
        )}
        
        <div className="p-8">
          <div className="flex items-start justify-between mb-6">
            <div className="flex-1">
              <div className="flex items-center space-x-3 mb-4">
                <span className={`px-3 py-1 rounded-full text-sm font-medium text-white bg-gradient-to-r ${getCategoryColor(event.category)}`}>
                  {event.category.charAt(0).toUpperCase() + event.category.slice(1)}
                </span>
                <span className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm font-medium">
                  {event.source}
                </span>
                {isDeadlineNear() && (
                  <span className="px-3 py-1 bg-red-100 text-red-700 rounded-full text-sm font-medium">
                    Deadline Soon!
                  </span>
                )}
              </div>
              
              <h1 className="text-3xl font-bold text-gray-800 mb-4">{event.title}</h1>
              <p className="text-gray-600 text-lg leading-relaxed">{event.description}</p>
            </div>
          </div>

          <div className="flex flex-wrap gap-4">
            <button
              onClick={handleBookmark}
              className={`flex items-center space-x-2 px-6 py-3 rounded-lg font-medium transition-all ${
                bookmarked
                  ? 'bg-yellow-100 text-yellow-700 hover:bg-yellow-200'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {bookmarked ? (
                <BookmarkSolidIcon className="w-5 h-5" />
              ) : (
                <BookmarkIcon className="w-5 h-5" />
              )}
              <span>{bookmarked ? 'Bookmarked' : 'Bookmark'}</span>
            </button>

            <a
              href={event.url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg font-medium hover:shadow-lg transform hover:-translate-y-0.5 transition-all"
            >
              <span>Apply Now</span>
              <ArrowTopRightOnSquareIcon className="w-5 h-5" />
            </a>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        {/* Event Details */}
        <div className="md:col-span-2 space-y-8">
          {/* Key Information */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-bold text-gray-800 mb-6">Event Information</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="flex items-center space-x-3">
                <CalendarDaysIcon className="w-6 h-6 text-blue-500" />
                <div>
                  <p className="font-medium text-gray-800">Start Date</p>
                  <p className="text-gray-600">{formatDate(event.startDate)}</p>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <ClockIcon className="w-6 h-6 text-red-500" />
                <div>
                  <p className="font-medium text-gray-800">Deadline</p>
                  <p className="text-gray-600">{formatDate(event.deadline)}</p>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <MapPinIcon className="w-6 h-6 text-green-500" />
                <div>
                  <p className="font-medium text-gray-800">Location</p>
                  <p className="text-gray-600">
                    {event.location} {event.isOnline && '(Online)'}
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <ChartBarIcon className="w-6 h-6 text-purple-500" />
                <div>
                  <p className="font-medium text-gray-800">Difficulty</p>
                  <p className="text-gray-600">{event.difficulty}</p>
                </div>
              </div>

              {event.company && (
                <div className="flex items-center space-x-3">
                  <BuildingOfficeIcon className="w-6 h-6 text-indigo-500" />
                  <div>
                    <p className="font-medium text-gray-800">Company</p>
                    <p className="text-gray-600">{event.company}</p>
                  </div>
                </div>
              )}

              {event.prize && (
                <div className="flex items-center space-x-3">
                  <TrophyIcon className="w-6 h-6 text-yellow-500" />
                  <div>
                    <p className="font-medium text-gray-800">Prize</p>
                    <p className="text-gray-600">{event.prize}</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Skills Required */}
          {event.skills && event.skills.length > 0 && (
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-xl font-bold text-gray-800 mb-4">Skills Required</h2>
              <div className="flex flex-wrap gap-2">
                {event.skills.map((skill: string, index: number) => (
                  <span
                    key={index}
                    className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Eligibility */}
          {event.eligibility && event.eligibility.length > 0 && (
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-xl font-bold text-gray-800 mb-4">Eligibility</h2>
              <ul className="list-disc list-inside space-y-2 text-gray-600">
                {event.eligibility.map((criterion: string, index: number) => (
                  <li key={index}>{criterion}</li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Quick Actions */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="font-bold text-gray-800 mb-4">Quick Actions</h3>
            <div className="space-y-3">
              <a
                href={event.url}
                target="_blank"
                rel="noopener noreferrer"
                className="block w-full text-center px-4 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg font-medium hover:shadow-lg transition-all"
              >
                View Original Post
              </a>
              <button
                onClick={handleBookmark}
                className={`block w-full px-4 py-3 rounded-lg font-medium transition-all ${
                  bookmarked
                    ? 'bg-yellow-100 text-yellow-700 hover:bg-yellow-200'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {bookmarked ? 'Remove Bookmark' : 'Add Bookmark'}
              </button>
            </div>
          </div>

          {/* Similar Events */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="font-bold text-gray-800 mb-4">Similar Events</h3>
            <Link
              to={`/events?category=${event.category}`}
              className="block text-blue-600 hover:text-blue-700 font-medium"
            >
              View more {event.category}s →
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EventDetails;
      