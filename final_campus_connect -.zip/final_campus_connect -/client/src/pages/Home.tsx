
// client/src/pages/Home.tsx
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import EventCard from '../components/EventCard';
import { 
  RocketLaunchIcon, 
  AcademicCapIcon, 
  BriefcaseIcon,
  TrophyIcon,
  ArrowRightIcon
} from '@heroicons/react/24/outline';

const Home: React.FC = () => {
  const [featuredEvents, setFeaturedEvents] = useState([]);
  const [stats, setStats] = useState({
    totalEvents: 0,
    activeHackathons: 0,
    internships: 0,
    competitions: 0
  });

  useEffect(() => {
    fetchFeaturedEvents();
    fetchStats();
  }, []);

  const fetchFeaturedEvents = async () => {
    try {
      const response = await axios.get(`${process.env.REACT_APP_API_URL}/events?limit=6&sortBy=createdAt&sortOrder=desc`);
      setFeaturedEvents(response.data.events);
    } catch (error) {
      console.error('Error fetching featured events:', error);
    }
  };

  const fetchStats = async () => {
    try {
      const [hackathons, internships, competitions] = await Promise.all([
        axios.get(`${process.env.REACT_APP_API_URL}/events?category=hackathon&limit=1`),
        axios.get(`${process.env.REACT_APP_API_URL}/events?category=internship&limit=1`),
        axios.get(`${process.env.REACT_APP_API_URL}/events?category=competition&limit=1`)
      ]);

      setStats({
        totalEvents: hackathons.data.pagination.total + internships.data.pagination.total + competitions.data.pagination.total,
        activeHackathons: hackathons.data.pagination.total,
        internships: internships.data.pagination.total,
        competitions: competitions.data.pagination.total
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const categories = [
    {
      name: 'Hackathons',
      description: 'Build innovative solutions and win prizes',
      icon: RocketLaunchIcon,
      color: 'from-purple-500 to-pink-500',
      link: '/events?category=hackathon',
      count: stats.activeHackathons
    },
    {
      name: 'Internships',
      description: 'Gain real-world experience',
      icon: BriefcaseIcon,
      color: 'from-blue-500 to-cyan-500',
      link: '/events?category=internship',
      count: stats.internships
    },
    {
      name: 'Competitions',
      description: 'Test your skills and compete',
      icon: TrophyIcon,
      color: 'from-green-500 to-emerald-500',
      link: '/events?category=competition',
      count: stats.competitions
    },
    {
      name: 'Workshops',
      description: 'Learn new skills and technologies',
      icon: AcademicCapIcon,
      color: 'from-orange-500 to-red-500',
      link: '/events?category=workshop',
      count: 0
    }
  ];

  return (
    <div className="space-y-16">
      {/* Hero Section */}
      <section className="text-center py-20">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
              Discover Amazing
            </span>
            <br />
            <span className="text-gray-800">Opportunities</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 leading-relaxed">
            Your one-stop platform for hackathons, internships, competitions, and workshops.
            Stay updated with the latest opportunities from top platforms.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/events"
              className="px-8 py-4 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl font-semibold hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200"
            >
              Explore Events
            </Link>
            <Link
              to="/login"
              className="px-8 py-4 border-2 border-gray-300 text-gray-700 rounded-xl font-semibold hover:border-blue-500 hover:text-blue-600 transition-all duration-200"
            >
              Get Started
            </Link>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-white rounded-2xl shadow-lg p-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          <div className="text-center">
            <div className="text-3xl font-bold text-blue-600 mb-2">{stats.totalEvents}+</div>
            <div className="text-gray-600">Total Events</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-purple-600 mb-2">{stats.activeHackathons}</div>
            <div className="text-gray-600">Hackathons</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-green-600 mb-2">{stats.internships}</div>
            <div className="text-gray-600">Internships</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-orange-600 mb-2">{stats.competitions}</div>
            <div className="text-gray-600">Competitions</div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section>
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-4">Explore Categories</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Find opportunities that match your interests and skills across different categories
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map((category) => (
            <Link
              key={category.name}
              to={category.link}
              className="group relative bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden"
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${category.color} opacity-0 group-hover:opacity-10 transition-opacity duration-300`}></div>
              <div className="p-6 relative">
                <div className={`inline-flex p-3 rounded-lg bg-gradient-to-br ${category.color} text-white mb-4`}>
                  <category.icon className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-2">{category.name}</h3>
                <p className="text-gray-600 mb-4">{category.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-500">{category.count} active</span>
                  <ArrowRightIcon className="w-5 h-5 text-gray-400 group-hover:text-blue-600 transform group-hover:translate-x-1 transition-all duration-200" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured Events */}
      <section>
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-3xl font-bold text-gray-800 mb-2">Latest Events</h2>
            <p className="text-gray-600">Recently added opportunities you shouldn't miss</p>
          </div>
          <Link
            to="/events"
            className="inline-flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-medium"
          >
            <span>View All</span>
            <ArrowRightIcon className="w-4 h-4" />
          </Link>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredEvents.slice(0, 6).map((event: any) => (
            <EventCard key={event._id} event={event} />
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl text-white p-12 text-center">
        <h2 className="text-3xl font-bold mb-4">Ready to Get Started?</h2>
        <p className="text-xl mb-8 opacity-90">
          Join thousands of students discovering amazing opportunities every day
        </p>
        <Link
          to="/login"
          className="inline-flex items-center space-x-2 bg-white text-blue-600 px-8 py-4 rounded-xl font-semibold hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200"
        >
          <span>Sign Up Now</span>
          <ArrowRightIcon className="w-5 h-5" />
        </Link>
      </section>
    </div>
  );
};

export default Home;