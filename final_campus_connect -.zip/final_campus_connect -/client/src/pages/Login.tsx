// client/src/pages/Login.tsx
import React, { useEffect, useCallback } from 'react'; // <-- added useCallback
import { Navigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import axios from 'axios';
import toast from 'react-hot-toast';

declare global {
  interface Window {
    google: any;
  }
}

const Login: React.FC = () => {
  const { user, login } = useAuth();

  // ✅ wrapped with useCallback so it's stable
  const handleGoogleResponse = useCallback(async (response: any) => {
    try {
      const result = await axios.post(`${process.env.REACT_APP_API_URL}/auth/google`, {
        token: response.credential
      });

      await login(result.data.token);
      toast.success('Login successful!');
    } catch (error) {
      console.error('Login error:', error);
      toast.error('Login failed. Please try again.');
    }
  }, [login]);

  useEffect(() => {
    // Load Google Sign-In script
    const script = document.createElement('script');
    script.src = 'https://accounts.google.com/gsi/client';
    script.async = true;
    script.defer = true;
    document.body.appendChild(script);

    script.onload = () => {
      if (window.google) {
        window.google.accounts.id.initialize({
          client_id: process.env.REACT_APP_GOOGLE_CLIENT_ID,
          callback: handleGoogleResponse
        });

        window.google.accounts.id.renderButton(
          document.getElementById('google-signin-button'),
          {
            theme: 'filled_blue',
            size: 'large',
            text: 'signin_with',
            width: 300
          }
        );
      }
    };

    return () => {
      document.body.removeChild(script);
    };
  }, [handleGoogleResponse]); // ✅ added dependency

  if (user) {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <div className="mx-auto h-20 w-20 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center mb-6">
            <span className="text-white font-bold text-2xl">EA</span>
          </div>
          <h2 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Welcome to EventsAggregator
          </h2>
          <p className="mt-4 text-gray-600">
            Sign in to access personalized events, bookmarks, and notifications
          </p>
        </div>

        <div className="bg-white p-8 rounded-xl shadow-lg">
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-lg font-medium mb-4">Sign in with Google</h3>
              <div id="google-signin-button" className="flex justify-center"></div>
            </div>

            <div className="text-sm text-gray-500 text-center">
              <p>By signing in, you agree to our Terms of Service and Privacy Policy</p>
            </div>
          </div>
        </div>

        <div className="text-center">
          <div className="grid grid-cols-3 gap-4 mt-8">
            <div className="bg-white p-4 rounded-lg shadow">
              <h4 className="font-semibold text-blue-600">10,000+</h4>
              <p className="text-sm text-gray-600">Events</p>
            </div>
            <div className="bg-white p-4 rounded-lg shadow">
              <h4 className="font-semibold text-purple-600">5,000+</h4>
              <p className="text-sm text-gray-600">Students</p>
            </div>
            <div className="bg-white p-4 rounded-lg shadow">
              <h4 className="font-semibold text-green-600">50+</h4>
              <p className="text-sm text-gray-600">Companies</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
