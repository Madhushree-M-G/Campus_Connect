// client/src/components/EventCard.tsx
import React from 'react';
import { Link } from 'react-router-dom';
import { 
  CalendarDaysIcon,
  MapPinIcon,
  ClockIcon,
  ArrowTopRightOnSquareIcon
} from '@heroicons/react/24/outline';

interface EventCardProps {
  event: {
    _id: string;
    title: string;
    description: string;
    category: string;
    source: string;
    url: string;
    imageUrl?: string;
    startDate: string;
    deadline: string;
    location: string;
    isOnline: boolean;
    skills: string[];
    prize?: string;
    company?: string;
    difficulty: string;
  };
}

const EventCard: React.FC<EventCardProps> = ({ event }) => {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric'
    });
  };

  const getCategoryColor = (category: string) => {
    const colors: { [key: string]: string } = {
      hackathon: 'from-purple-500 to-pink-500',
      internship: 'from-blue-500 to-cyan-500',
      competition: 'from-green-500 to-emerald-500',
      workshop: 'from-orange-500 to-red-500'
    };
    return colors[category] || 'from-gray-500 to-gray-600';
  };

  const isDeadlineNear = () => {
    const deadline = new Date(event.deadline);
    const now = new Date();
    const daysLeft = Math.ceil((deadline.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return daysLeft <= 7;
  };

  return (
    <div className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden group">
      {/* Image */}
      <div className="h-48 bg-gradient-to-br from-blue-50 to-purple-50 relative overflow-hidden">
        {event.imageUrl ? (
          <img
            src={event.imageUrl}
            alt={event.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className={`w-full h-full bg-gradient-to-br ${getCategoryColor(event.category)} flex items-center justify-center`}>
            <span className="text-white text-4xl font-bold">
              {event.category.charAt(0).toUpperCase()}
            </span>
          </div>
        )}
        
        {/* Category Badge */}
        <div className="absolute top-4 left-4">
          <span className={`px-3 py-1 rounded-full text-sm font-medium text-white bg-gradient-to-r ${getCategoryColor(event.category)}`}>
            {event.category.charAt(0).toUpperCase() + event.category.slice(1)}
          </span>
        </div>

        {/* Deadline Warning */}
        {isDeadlineNear() && (
          <div className="absolute top-4 right-4">
            <span className="px-2 py-1 bg-red-500 text-white rounded-full text-xs font-medium">
              Urgent!
            </span>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-6">
        <div className="mb-3">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-blue-600">{event.source}</span>
            <span className="text-sm text-gray-500">{event.difficulty}</span>
          </div>
          <h3 className="text-lg font-bold text-gray-800 mb-2 line-clamp-2 group-hover:text-blue-600 transition-colors">
            {event.title}
          </h3>
          <p className="text-gray-600 text-sm line-clamp-2 mb-4">
            {event.description}
          </p>
        </div>

        {/* Event Details */}
        <div className="space-y-2 mb-4">
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <CalendarDaysIcon className="w-4 h-4" />
            <span>Starts {formatDate(event.startDate)}</span>
          </div>
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <ClockIcon className="w-4 h-4" />
            <span>Deadline {formatDate(event.deadline)}</span>
          </div>
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <MapPinIcon className="w-4 h-4" />
            <span>{event.location} {event.isOnline && '(Online)'}</span>
          </div>
        </div>

        {/* Skills */}
        {event.skills && event.skills.length > 0 && (
          <div className="mb-4">
            <div className="flex flex-wrap gap-1">
              {event.skills.slice(0, 3).map((skill, index) => (
                <span
                  key={index}
                  className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs"
                >
                  {skill}
                </span>
              ))}
              {event.skills.length > 3 && (
                <span className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs">
                  +{event.skills.length - 3} more
                </span>
              )}
            </div>
          </div>
        )}

        {/* Prize */}
        {event.prize && (
          <div className="mb-4">
            <span className="inline-flex items-center px-2 py-1 bg-yellow-100 text-yellow-800 rounded-full text-xs font-medium">
              🏆 {event.prize}
            </span>
          </div>
        )}

        {/* Actions */}
        <div className="flex items-center justify-between">
          <Link
            to={`/events/${event._id}`}
            className="text-blue-600 hover:text-blue-700 font-medium text-sm"
          >
            View Details
          </Link>
          <a
            href={event.url}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center space-x-1 px-3 py-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg text-sm font-medium hover:shadow-lg transition-all"
          >
            <span>Apply</span>
            <ArrowTopRightOnSquareIcon className="w-4 h-4" />
          </a>
        </div>
      </div>
    </div>
  );
};

export default EventCard;