// client/src/components/SearchFilters.tsx
import React from 'react';
import { MagnifyingGlassIcon, FunnelIcon } from '@heroicons/react/24/outline';

interface SearchFiltersProps {
  filters: {
    category: string;
    search: string;
    skills: string;
    location: string;
    isOnline: boolean;
    sortBy: string;
    sortOrder: string;
  };
  onFilterChange: (filters: any) => void;
}

const SearchFilters: React.FC<SearchFiltersProps> = ({ filters, onFilterChange }) => {
  const categories = [
    { value: 'all', label: 'All Categories' },
    { value: 'hackathon', label: 'Hackathons' },
    { value: 'internship', label: 'Internships' },
    { value: 'competition', label: 'Competitions' },
    { value: 'workshop', label: 'Workshops' }
  ];

  const popularSkills = [
    'JavaScript', 'Python', 'React', 'Node.js', 'Java', 'C++',
    'Machine Learning', 'Data Science', 'Web Development', 'Mobile Development',
    'UI/UX Design', 'DevOps', 'Cloud Computing', 'Blockchain'
  ];

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 space-y-6">
      <div className="flex items-center space-x-2 mb-4">
        <FunnelIcon className="w-5 h-5 text-gray-600" />
        <h2 className="text-lg font-semibold text-gray-800">Search & Filter</h2>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <MagnifyingGlassIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
        <input
          type="text"
          placeholder="Search events, companies, or keywords..."
          value={filters.search}
          onChange={(e) => onFilterChange({ search: e.target.value })}
          className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Category Filter */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Category
          </label>
          <select
            value={filters.category}
            onChange={(e) => onFilterChange({ category: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            {categories.map((category) => (
              <option key={category.value} value={category.value}>
                {category.label}
              </option>
            ))}
          </select>
        </div>

        {/* Skills Filter */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Skills
          </label>
          <input
            type="text"
            placeholder="e.g., JavaScript, Python"
            value={filters.skills}
            onChange={(e) => onFilterChange({ skills: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        {/* Location Filter */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Location
          </label>
          <input
            type="text"
            placeholder="City or Online"
            value={filters.location}
            onChange={(e) => onFilterChange({ location: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        {/* Online Only Filter */}
        <div className="flex items-center">
          <label className="flex items-center space-x-2 cursor-pointer">
            <input
              type="checkbox"
              checked={filters.isOnline}
              onChange={(e) => onFilterChange({ isOnline: e.target.checked })}
              className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
            <span className="text-sm font-medium text-gray-700">Online Only</span>
          </label>
        </div>
      </div>

      {/* Popular Skills */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-3">
          Popular Skills
        </label>
        <div className="flex flex-wrap gap-2">
          {popularSkills.map((skill) => (
            <button
              key={skill}
              onClick={() => onFilterChange({ skills: skill })}
              className="px-3 py-1 bg-gray-100 hover:bg-blue-100 text-gray-700 hover:text-blue-700 rounded-full text-sm transition-colors"
            >
              {skill}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SearchFilters;